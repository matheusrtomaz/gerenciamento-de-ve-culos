package com.nassau.gerenciamentodeveiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciamentoDeVeiculosApplicationTests {

    @Test
    void contextLoads() {
    }

}
