package com.nassau.gerenciamentodeveiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoDeVeiculosApplication {

    public static void main(String[] args) {
        SpringApplication.run(GerenciamentoDeVeiculosApplication.class, args);
    }

}
